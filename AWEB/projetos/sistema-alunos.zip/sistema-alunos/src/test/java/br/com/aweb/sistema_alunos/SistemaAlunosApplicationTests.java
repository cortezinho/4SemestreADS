package br.com.aweb.sistema_alunos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaAlunosApplicationTests {

	@Test
	void contextLoads() {
	}

}
