package br.com.aweb.sistema_alunos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaAlunosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaAlunosApplication.class, args);
	}

}
